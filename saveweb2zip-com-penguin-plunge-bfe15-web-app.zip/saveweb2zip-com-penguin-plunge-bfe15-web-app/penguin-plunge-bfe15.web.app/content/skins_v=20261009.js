/* Penguin Plunge - SKINS
   See CONTRIBUTING.md for the step-by-step guide. Add one entry, add your image to assets/, run: node tools/validate-content.js */
window.PP_CONTENT=window.PP_CONTENT||{};

/* ---------------------------------------------------------------------------
   1) originalSkins - free "original" penguins that use a texture from
      assets/original-penguins/.
      id          unique, lowercase, no spaces (saved in player profiles - never change it later)
      name        shown in the game
      fbxSkin     mesh name inside Penguins.fbx (copy an existing one unless you edited the model)
      fbxTexture  file in assets/original-penguins/
      fallback    [0, bodyColor, bellyColor, accentColor, 0] used for previews (0xRRGGBB hex)
      emoji       icon in menus
   --------------------------------------------------------------------------- */
PP_CONTENT.originalSkins=[
 {id:'black',name:'Black Penguin',fbxSkin:'PenguinBlack',fbxTexture:'penguin-tex-black.png',fallback:[0,0x1f2d3d,0xffffff,0x3d8bff,0],emoji:'🖤'},
 {id:'orange',name:'Orange Penguin',fbxSkin:'PenguinOrange',fbxTexture:'penguin-tex-orange.png',fallback:[0,0xf07824,0xffe0bd,0x3d8bff,0],emoji:'🧡'},
 {id:'green',name:'Green Penguin',fbxSkin:'PenguinGreen',fbxTexture:'penguin-tex-green.png',fallback:[0,0x2f9e44,0xe8ffd9,0x1f6f3d,0],emoji:'💚'},
 {id:'blue-dark',name:'Dark Blue Penguin',fbxSkin:'PenguinBlueDark',fbxTexture:'penguin-tex-blue-dark.png',fallback:[0,0x183b73,0xd7ecff,0x174ea6,0],emoji:'💙'},
 {id:'blue',name:'Blue Penguin',fbxSkin:'PenguinBlue',fbxTexture:'penguin-tex-blue.png',fallback:[0,0x3d8bff,0xeaf6ff,0xffffff,0],emoji:'🔵'},
 {id:'purple',name:'Purple Penguin',fbxSkin:'PenguinPurple',fbxTexture:'penguin-tex-purple.png',fallback:[0,0x7047b8,0xf1ddff,0xffd23f,0],emoji:'💜'},
 {id:'red',name:'Red Penguin',fbxSkin:'PenguinRed',fbxTexture:'penguin-tex-red.png',fallback:[0,0xc62828,0xffe3e3,0xffc107,0],emoji:'❤️'},
 {id:'yellow',name:'Yellow Penguin',fbxSkin:'PenguinYellow',fbxTexture:'penguin-tex-yellow.png',fallback:[0,0xf2c300,0xfff7cf,0x8d6e00,0],emoji:'💛'},
 {id:'brown',name:'Brown Penguin',fbxSkin:'PenguinBrown',fbxTexture:'penguin-tex-brown.png',fallback:[0,0x6b4429,0xf5deb3,0xff6b6b,0],emoji:'🤎'},
 {id:'gray',name:'Gray Penguin',fbxSkin:'PenguinGray',fbxTexture:'penguin-tex-gray.png',fallback:[0,0x78828d,0xf0f3f5,0x455a64,0],emoji:'🩶'},
 {id:'gray-dark',name:'Dark Gray Penguin',fbxSkin:'PenguinGrayDark',fbxTexture:'penguin-tex-gray-dark.png',fallback:[0,0x37414b,0xe2e6ea,0x90a4ae,0],emoji:'🩶'},
 {id:'green-dark',name:'Dark Green Penguin',fbxSkin:'PenguinGreenDark',fbxTexture:'penguin-tex-green-dark.png',fallback:[0,0x155d38,0xdff7e7,0x8bc34a,0],emoji:'🟢'},
 {id:'pink',name:'Pink Penguin',fbxSkin:'PenguinPink',fbxTexture:'penguin-tex-pink.png',fallback:[0,0xf58ab0,0xffeef5,0xffc107,0],emoji:'🩷'},
 {id:'masked',name:'Masked Penguin',fbxSkin:'PenguinFull',fbxTexture:'penguin-tex-mask.png',fallback:[0,0x252a34,0xf1f1f1,0x8f7cff,0],emoji:'🎭'}
];

/* ---------------------------------------------------------------------------
   2) originalAccessories - optional extras for the original penguins
      (mesh + texture from the Penguins.fbx / assets/original-penguins/).
   --------------------------------------------------------------------------- */
PP_CONTENT.originalAccessories=[
 {id:'cape',name:'Cape',mesh:'cape',texture:'tex_cape.png',emoji:'🦸'},
 {id:'headphone',name:'Headphones',mesh:'Headphone',texture:'tex_headphone.png',emoji:'🎧'},
 {id:'rabbit-hat',name:'Rabbit Hat',mesh:'rabbithat',texture:'tex_rabbithat.png',emoji:'🐰'},
 {id:'samurai',name:'Samurai',mesh:'samurai',texture:'tex_samurai.png',emoji:'🥷'},
 {id:'samurai-hat',name:'Samurai Hat',mesh:'samuraiHat',texture:'tex_samuraiHat.png',emoji:'⛩️'},
 {id:'skateboard',name:'Skateboard',mesh:'skater',texture:'tex_skater.png',emoji:'🛹'},
 {id:'suit',name:'Suit',mesh:'suit',texture:'tex_suit.png',emoji:'🤵'},
 {id:'fish',name:'Fish',mesh:'Fish',texture:'tex_fish.png',emoji:'🐟'},
 {id:'jacket',name:'Jacket',mesh:'jacket',texture:'tex_jacket.png',emoji:'🧥'}
];

/* ---------------------------------------------------------------------------
   3) shopItems - skins sold in the shop (colour skins painted with 4 colours).
      id        unique, lowercase, no spaces (never change it later)
      name      shown in the game
      cost      price
      currency  'coins' or 'gems'
      sk        [0, bodyColor, bellyColor, accentColor, 0]  (0xRRGGBB hex colours)
      emoji     icon in menus
      rarity    'Common' | 'Rare' | 'Epic' | 'Legendary' | 'Halloween'
      acc       (optional) name of a themed accessory, e.g. 'Witch Hat'
   --------------------------------------------------------------------------- */
PP_CONTENT.shopItems=[
 {id:'classic',name:'Classic',cost:0,currency:'coins',sk:['Classic',0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Penguin.png',rarity:'Common'},
 {id:'pumpkin',name:'Pumpkin Penguin',cost:750,currency:'coins',sk:[0,0xf07b24,0xffd8a8,0x5b2bd0,0],emoji:'🎃',rarity:'Halloween',styles:[
  {id:'lantern',name:'Lantern Glow',sk:[0,0xff8a24,0xffe2a8,0x43235f,0],detail:'pumpkin'},
  {id:'moonlit',name:'Moonlit',sk:[0,0x38445f,0xe7ecff,0xffbd3f,0],detail:'stars'}
 ]},
 {id:'ghost',name:'Ghost Penguin',cost:40,currency:'gems',sk:[0,0xdde8ff,0xffffff,0x8f7cff,0],emoji:'👻',rarity:'Halloween',styles:[
  {id:'wisp',name:'Blue Wisp',sk:[0,0x9deaff,0xf5ffff,0x42b9e8,0],detail:'stars'},
  {id:'haunted',name:'Haunted',sk:[0,0x9c91b8,0xe9e2f2,0x542a78,0],detail:'web'}
 ]},
 {id:'witch',name:'Witch Penguin',cost:1200,currency:'coins',sk:[5,0x34104f,0xe9c2ff,0x111111,5,0x2d123d,0],emoji:'🧙',rarity:'Halloween',acc:'Witch Hat',styles:[
  {id:'midnight',name:'Midnight Spell',sk:[0,0x201635,0xc9c2e8,0x55d9a4,0],detail:'runes'},
  {id:'ember',name:'Ember Spell',sk:[0,0x54243a,0xffd2ad,0xff7b32,0],detail:'stars'}
 ]},
 {id:'candy',name:'Candy Corn',cost:65,currency:'gems',sk:[0,0x6c2bd9,0xffc1e9,0xff9d1a,0,0,7],emoji:'🍬',rarity:'Halloween',acc:'Candy Mask'},
 {id:'vampire',name:'Vampire',cost:1800,currency:'coins',sk:[0,0x32152f,0xf3d5e8,0x9b111e,0,0,3],emoji:'🦇',rarity:'Halloween',acc:'Vampire Fangs'},
 {id:'frost',name:'Frostbite',cost:900,currency:'coins',sk:[0,0x6bdcff,0xf5ffff,0x2e72d2,0],emoji:'❄️',rarity:'Rare'},
 {id:'skeleton',name:'Skeleton',cost:85,currency:'gems',sk:[0,0x202020,0xf5f0d8,0x9a9a9a,0,0,2],emoji:'💀',rarity:'Halloween',acc:'Skull Mask'},
 {id:'zombie',name:'Zombie',cost:1450,currency:'coins',sk:[0,0x315f38,0xb8e59b,0x5b2d86,0,0,6],emoji:'🧟',rarity:'Halloween',acc:'Zombie Wrap',detail:'zombie'},
 {id:'pumpkinking',name:'Pumpkin King',cost:110,currency:'gems',sk:[0,0xc94c14,0xffe0a8,0x3a185f,0],emoji:'🎃',rarity:'Legendary'},
 {id:'shadow',name:'Shadow',cost:95,currency:'gems',sk:[0,0x0b1020,0x4f5875,0x171b2d,0],emoji:'🌑',rarity:'Epic'},
 {id:'sunset',name:'Sunset',cost:700,currency:'coins',sk:[0,0xff6b35,0xffd166,0x7a2cff,0],emoji:'🌅',rarity:'Rare'},
 {id:'ocean',name:'Ocean',cost:650,currency:'coins',sk:[0,0x1261a0,0x8deaff,0x0b3d91,0],emoji:'🌊',rarity:'Rare'},
 {id:'volcano',name:'Volcano',cost:1500,currency:'coins',sk:[0,0x7d1d1d,0xffb000,0x2b0b0b,0],emoji:'🌋',rarity:'Epic'},
 {id:'emerald',name:'Emerald',cost:55,currency:'gems',sk:[0,0x075e54,0xb8ffce,0x0f9d58,0],emoji:'💚',rarity:'Epic'},
 {id:'sapphire',name:'Sapphire',cost:55,currency:'gems',sk:[0,0x0d47a1,0xb9e6ff,0x1565c0,0],emoji:'💙',rarity:'Epic'},
 {id:'ruby',name:'Ruby',cost:55,currency:'gems',sk:[0,0x8e0000,0xffc1c1,0xd50000,0],emoji:'❤️',rarity:'Epic'},
 {id:'amethyst',name:'Amethyst',cost:60,currency:'gems',sk:[0,0x4a148c,0xf0c8ff,0x8e24aa,0],emoji:'💜',rarity:'Epic'},
 {id:'gold',name:'Golden',cost:2200,currency:'coins',sk:[0,0xb8860b,0xfff1a8,0xffc107,0],emoji:'👑',rarity:'Legendary'},
 {id:'silver',name:'Silver',cost:1300,currency:'coins',sk:[0,0x65717d,0xffffff,0xb0bec5,0],emoji:'🥈',rarity:'Rare'},
 {id:'neonpink',name:'Neon Pink',cost:70,currency:'gems',sk:[0,0xff1493,0xffd1f0,0x7a00ff,0],emoji:'💗',rarity:'Epic'},
 {id:'neonblue',name:'Neon Blue',cost:70,currency:'gems',sk:[0,0x00a8ff,0xd6f7ff,0x004cff,0],emoji:'💠',rarity:'Epic'},
 {id:'neongreen',name:'Neon Green',cost:70,currency:'gems',sk:[0,0x00c853,0xd8ffd8,0x00a152,0],emoji:'💚',rarity:'Epic'},
 {id:'cosmic',name:'Cosmic',cost:130,currency:'gems',sk:[0,0x24104f,0xe8c7ff,0x6f42c1,0],emoji:'🌌',rarity:'Legendary'},
 {id:'galaxy',name:'Galaxy',cost:2800,currency:'coins',sk:[0,0x15153f,0xf3d6ff,0x4b0082,0],emoji:'🌠',rarity:'Legendary',detail:'galaxy'},
 {id:'astronaut',name:'Astronaut',cost:105,currency:'gems',sk:[0,0x6d7c91,0xffffff,0x1f4d8f,0],emoji:'🚀',rarity:'Epic'},
 {id:'robot',name:'Robot',cost:1700,currency:'coins',sk:[0,0x3c4654,0xd9e3ea,0x00a6a6,0],emoji:'🤖',rarity:'Epic'},
 {id:'ninja',name:'Ninja',cost:90,currency:'gems',sk:[0,0x111111,0x5c5c5c,0xe53935,0],emoji:'🥷',rarity:'Epic'},
 {id:'samurai',name:'Samurai',cost:1900,currency:'coins',sk:[0,0x4a0e0e,0xf1d5b8,0xd4af37,0],emoji:'⚔️',rarity:'Legendary'},
 {id:'pirate',name:'Pirate',cost:1600,currency:'coins',sk:[0,0x16213e,0xffe0b2,0xd32f2f,0],emoji:'🏴‍☠️',rarity:'Epic'},
 {id:'captain',name:'Captain',cost:100,currency:'gems',sk:[0,0x0b3d91,0xffffff,0xffc107,0],emoji:'⚓',rarity:'Rare',detail:'captain'},
 {id:'firefighter',name:'Firefighter',cost:1200,currency:'coins',sk:[0,0xb71c1c,0xffe0b2,0xffd600,0],emoji:'🚒',rarity:'Rare'},
 {id:'police',name:'Police',cost:1200,currency:'coins',sk:[0,0x102a43,0xf5d6ba,0x64b5f6,0],emoji:'🚓',rarity:'Rare'},
 {id:'doctor',name:'Doctor',cost:80,currency:'gems',sk:[0,0xffffff,0xffe5d1,0x29b6f6,0],emoji:'🩺',rarity:'Rare'},
 {id:'chef',name:'Chef',cost:950,currency:'coins',sk:[0,0xfafafa,0xffd7c2,0xd32f2f,0],emoji:'👨‍🍳',rarity:'Rare'},
 {id:'sports',name:'All-Star',cost:75,currency:'gems',sk:[0,0x1565c0,0xffffff,0xff1744,0],emoji:'🏆',rarity:'Epic'},
 {id:'basketball',name:'Hoops',cost:900,currency:'coins',sk:[0,0xff6f00,0xffe0b2,0x3f51b5,0],emoji:'🏀',rarity:'Rare'},
 {id:'soccer',name:'Soccer Star',cost:900,currency:'coins',sk:[0,0x263238,0xffffff,0x43a047,0],emoji:'⚽',rarity:'Rare'},
 {id:'icecream',name:'Ice Cream',cost:65,currency:'gems',sk:[0,0xff9ecf,0xfff4ff,0x7e57c2,0],emoji:'🍦',rarity:'Rare'},
 {id:'watermelon',name:'Watermelon',cost:650,currency:'coins',sk:[0,0x2e7d32,0xffd7d7,0xe53935,0],emoji:'🍉',rarity:'Common'},
 {id:'lemon',name:'Lemon',cost:600,currency:'coins',sk:[0,0xe0a800,0xffffcc,0x76b947,0],emoji:'🍋',rarity:'Common'},
 {id:'mint',name:'Mint Chip',cost:55,currency:'gems',sk:[0,0x2e8b7d,0xd9fff1,0x5e35b1,0],emoji:'🍃',rarity:'Rare'},
 {id:'chocolate',name:'Chocolate',cost:600,currency:'coins',sk:[0,0x4e342e,0xffd9b8,0x795548,0],emoji:'🍫',rarity:'Common',detail:'chocolate'},
 {id:'rainbow',name:'Rainbow',cost:150,currency:'gems',sk:[0,0x8e44ad,0xfff3b0,0x00bcd4,0],emoji:'🌈',rarity:'Legendary'},
 {id:'aurora',name:'Aurora',cost:125,currency:'gems',sk:[0,0x174f4f,0xd4fff7,0x6a5acd,0],emoji:'✨',rarity:'Legendary'},
 {id:'storm',name:'Thunderstorm',cost:1800,currency:'coins',sk:[0,0x263238,0xd6e4ff,0x00acc1,0],emoji:'⛈️',rarity:'Epic',detail:'storm'},
 {id:'cloud',name:'Cloud Nine',cost:70,currency:'gems',sk:[0,0x9aa7b8,0xffffff,0x90caf9,0],emoji:'☁️',rarity:'Rare'},
 {id:'honey',name:'Honey',cost:700,currency:'coins',sk:[0,0xd18b00,0xfff0a6,0x6d4c41,0],emoji:'🍯',rarity:'Common',detail:'honey'},
 {id:'slime',name:'Slime',cost:60,currency:'gems',sk:[0,0x4caf50,0xd9ffd9,0x76ff03,0],emoji:'🟢',rarity:'Epic'},
 {id:'arcade',name:'Arcade',cost:110,currency:'gems',sk:[0,0x1a237e,0xfff59d,0xff4081,0],emoji:'🕹️',rarity:'Epic'},
 {id:'disco',name:'Disco',cost:105,currency:'gems',sk:[0,0x311b92,0xffe082,0x00e5ff,0],emoji:'🪩',rarity:'Legendary'},
 {id:'spaceghost',name:'Space Ghost',cost:150,currency:'gems',sk:[0,0x283593,0xe3f2fd,0x00e5ff,0],emoji:'👻',rarity:'Legendary'},
 {id:'reaper',name:'Reaper',cost:2500,currency:'coins',sk:[0,0x171717,0xd8d8d8,0x7b1fa2,0],emoji:'☠️',rarity:'Legendary'},
 {id:'mummy',name:'Mummy Penguin',cost:950,currency:'coins',sk:[0,0x716553,0xf0e2c5,0x8b6b3e,0],emoji:'🧻',rarity:'Halloween',detail:'bandage'},
 {id:'blackcat',name:'Black Cat',cost:75,currency:'gems',sk:[0,0x211d2b,0xd7cde8,0xffa52d,0],emoji:'🐈‍⬛',rarity:'Halloween',detail:'stars'},
 {id:'spiderweb',name:'Spiderweb',cost:1100,currency:'coins',sk:[0,0x292239,0xe8e1f2,0xb88cff,0],emoji:'🕸️',rarity:'Halloween',detail:'web'},
 {id:'shades3d_vogue',name:'Vogue Shades 3D',cost:120,currency:'gems',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Glasses.png',rarity:'Legendary',face3d:'3d:vogue'},
 {id:'shades3d_tommy',name:'Tommy Shades 3D',cost:95,currency:'gems',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Glasses.png',rarity:'Rare',face3d:'3d:tommy'},
 {id:'shades3d_rayban',name:'Rayban Shades 3D',cost:85,currency:'gems',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Glasses.png',rarity:'Rare',face3d:'3d:rayban'},
 {id:'shades3d_osse',name:'Osse Shades 3D',cost:85,currency:'gems',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Glasses.png',rarity:'Rare',face3d:'3d:osse'},
 {id:'shades3d_inesta3',name:'Inesta Shield 3D',cost:85,currency:'gems',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Glasses.png',rarity:'Epic',face3d:'3d:inesta3'},
 {id:'shades3d_inesta2',name:'Inesta Sport 3D',cost:85,currency:'gems',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Glasses.png',rarity:'Rare',face3d:'3d:inesta2'},
 {id:'shades3d_inesta1',name:'Inesta Classic 3D',cost:85,currency:'gems',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Glasses.png',rarity:'Rare',face3d:'3d:inesta1'},
 {id:'shades3d_mustang',name:'Mustang Shades 3D',cost:85,currency:'gems',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Glasses.png',rarity:'Rare',face3d:'3d:mustang'},
 {id:'pumpkinlantern',name:'Pumpkin Lantern',cost:20,currency:'coins',sk:[0,0x5a2b18,0xffd58a,0xff7a18,0],emoji:'🏮',rarity:'Halloween',detail:'pumpkin'},
 {id:'batwings',name:'Bat Wings',cost:25,currency:'gems',sk:[0,0x24133d,0xe3c7ff,0x7b2cbf,0],emoji:'🦇',rarity:'Halloween',detail:'web'},
 {id:'hauntedscarf',name:'Haunted Scarf',cost:20,currency:'coins',sk:[0,0x2b1b4d,0xe7ddff,0xff7a18,0],emoji:'🧣',rarity:'Halloween',detail:'stars'},
 {id:'ghostballoon',name:'Ghost Balloon',cost:25,currency:'gems',sk:[0,0xdce9ff,0xffffff,0x8f7cff,0],emoji:'👻',rarity:'Halloween',detail:'stars'},
 {id:'witchbrew',name:"Witch's Brew",cost:0,currency:'coins',sk:[0,0x251331,0xb9ff9b,0x8e44ad,0],emoji:'🧪',rarity:'Halloween',detail:'runes',questOnly:true},
 {id:'graveyardghoul',name:'Graveyard Ghoul',cost:0,currency:'coins',sk:[0,0x1b1b24,0xb6b8c8,0x4f596d,0],emoji:'🪦',rarity:'Halloween',detail:'web',questOnly:true},
 /* 3D hats: locked until bought. Buying one unlocks it in the Locker. */
 {id:'hat_winter',name:'Winter Hat',cost:450,currency:'coins',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Hat.png',rarity:'Common',kind:'hat',shopPermanent:true,hatId:'pack:winter'},
 {id:'hat_child',name:'Child Hat',cost:450,currency:'coins',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Hat.png',rarity:'Common',kind:'hat',shopPermanent:true,hatId:'pack:child'},
 {id:'hat_irish',name:'Irish Hat',cost:600,currency:'coins',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Hat.png',rarity:'Rare',kind:'hat',shopPermanent:true,hatId:'pack:irish'},
 {id:'hat_helmet',name:'Helmet',cost:700,currency:'coins',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Hat.png',rarity:'Rare',kind:'hat',shopPermanent:true,hatId:'pack:helmet'},
 {id:'hat_hardhat',name:'Hard Hat',cost:650,currency:'coins',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Hat.png',rarity:'Rare',kind:'hat',shopPermanent:true,hatId:'pack:hardhat'},
 {id:'hat_monk',name:'Monk Hat',cost:45,currency:'gems',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Hat.png',rarity:'Rare',kind:'hat',shopPermanent:true,hatId:'pack:monk'},
 {id:'hat_gentleman',name:'Gentleman Hat',cost:55,currency:'gems',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Hat.png',rarity:'Epic',kind:'hat',shopPermanent:true,hatId:'pack:gentleman'},
 {id:'hat_pirate',name:'Pirate Hat',cost:1200,currency:'coins',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Hat.png',rarity:'Epic',kind:'hat',shopPermanent:true,hatId:'pack:pirate'},
 {id:'hat_viking',name:'Viking Helmet',cost:70,currency:'gems',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Hat.png',rarity:'Epic',kind:'hat',shopPermanent:true,hatId:'pack:viking'},
 {id:'hat_pope',name:'Pope Hat',cost:90,currency:'gems',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Hat.png',rarity:'Legendary',kind:'hat',shopPermanent:true,hatId:'pack:pope'},
 {id:'hat_wizard3d',name:'Wizzard Hat',cost:1800,currency:'coins',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Hat.png',rarity:'Legendary',kind:'hat',shopPermanent:true,hatId:'pack:wizard3d'},
 {id:'hat_crown3d',name:'Crown',cost:120,currency:'gems',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Hat.png',rarity:'Legendary',kind:'hat',shopPermanent:true,hatId:'pack:crown3d'},
 {id:'hat_cowboy',name:'Cowboy Hat',cost:800,currency:'coins',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Hat.png',rarity:'Rare',kind:'hat',shopPermanent:true,hatId:'pack:cowboy'},
 {id:'hat_pumpkin',name:'Pumpkin Hat',cost:75,currency:'gems',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Hat.png',rarity:'Halloween',kind:'hat',shopPermanent:true,hatId:'pack:pumpkin'},
 {id:'hat_lowpolycap',name:'Lowpoly Cap',cost:500,currency:'coins',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Hat.png',rarity:'Common',kind:'hat',shopPermanent:true,hatId:'pack:lowpolycap'},
 {id:'hat_knitwinter',name:'Knit Winter Hat',cost:50,currency:'gems',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Hat.png',rarity:'Rare',kind:'hat',shopPermanent:true,hatId:'pack:knitwinter'},
 {id:'hat_goggles',name:'Swimming Goggles',cost:500,currency:'coins',sk:[0,0x1f2d3d,0xffffff,0x3d8bff,0],icon:'assets/Glasses.png',rarity:'Common',face3d:'3d:goggles',kind:'glasses',shopPermanent:true}
];
