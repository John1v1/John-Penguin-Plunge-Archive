/* Penguin Plunge - RACE MAPS
   See CONTRIBUTING.md for the step-by-step guide. Validate with: node tools/validate-content.js */
window.PP_CONTENT=window.PP_CONTENT||{};

/* ---------------------------------------------------------------------------
   customRaceMaps - extra race courses. The six original maps are built in code;
   anything you add here is mixed into the random map rotation.

   Your platforms replace the MIDDLE of the course. Every race still gets the same
   start (the big starting pad + three lane platforms) and the same finish
   (stairs, big platform with sweepers, finale and finish line) around it.

   Platforms are listed in order, from the start toward the finish.

   name       shown in the game, must be unique
   theme      0-3, changes the colour of the side rails (optional)
   platforms  list of platforms, each with:
      x         left/right position, -6 to 6  (0 = centre)
      len       length (front to back), 2 to 24
      w         width, 1.5 to 14
      y         height, 0 to 3 (optional, default 0)
      gap       empty space before the NEXT platform, 0 to 3 (optional, default 2).
                Bigger gaps are not jumpable, and jumping UP more than ~1 per gap is hard.
      cp        checkpoint number (optional) - players respawn here after falling.
                Use 0 for none, and increasing numbers 1, 2, 3 ... along the course.
      crumble   true = the platform breaks soon after being stepped on (optional)
      sweeper   spinning bar hazard on this platform (optional):
                  { len: 8, speed: 1.8 }   speed can be negative to spin the other way
                  dz (optional) moves the bar forward/back from the platform centre
   --------------------------------------------------------------------------- */
PP_CONTENT.customRaceMaps=[
  {
    name:'Zigzag Starter',   // example map - copy it, rename it and change the numbers
    theme:1,
    platforms:[
      {x:-3, len:3.6, w:3.4},
      {x: 3, len:3.6, w:3.4},
      {x:-3, len:3.6, w:3.4},
      {x: 3, len:3.6, w:3.4, cp:1},
      {x: 0, len:3.0, w:3.0, crumble:true},
      {x: 0, len:3.0, w:3.0, crumble:true},
      {x: 0, len:12,  w:9,   cp:2, sweeper:{len:7, speed:1.8}}
    ]
  }
];
