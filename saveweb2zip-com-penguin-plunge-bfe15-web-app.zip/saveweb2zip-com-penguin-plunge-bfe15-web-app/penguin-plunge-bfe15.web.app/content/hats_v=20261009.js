/* Penguin Plunge - HATS & GLASSES
   See CONTRIBUTING.md for the step-by-step guide. */
window.PP_CONTENT=window.PP_CONTENT||{};

/* ---------------------------------------------------------------------------
   1) lowpolyHats - 3D hats. Each row is  [id, 'Display Name', 'FileName']
      The file must be  assets/3d-hats/FileName.glb
      id must be unique and never changed later (saved in player profiles).
      After adding a hat, add a matching row to pudgyHatSpec below so it sits on the head.
   --------------------------------------------------------------------------- */
PP_CONTENT.lowpolyHats=[
 ['winter','Winter Hat','WinterHat'],['viking','Viking Helmet','VikingHelmet'],['helmet','Helmet','Helmet'],
 ['pirate','Pirate Hat','PirateHat'],['child','Child Hat','ChildHat'],['wizard3d','Wizzard Hat','WizzardHat'],
 ['irish','Irish Hat','IrishHat'],['pope','Pope Hat','PopeHat'],['monk','Monk Hat','MonkHat'],
 ['gentleman','Gentleman Hat','GentlemanHat'],['crown3d','Crown','Crown'],
 ['cowboy','Cowboy Hat','CowboyHat'],
 ['pumpkin','Pumpkin Hat','PumpkinHat'],
 ['hardhat','Hard Hat','HardHat'],
 ['lowpolycap','Lowpoly Cap','Cap'],
 ['sheriff',"Sheriff's Hat",'SheriffHat'],
 ['knitwinter','Knit Winter Hat','KnitWinterHat']
];

/* ---------------------------------------------------------------------------
   2) pudgyHatSpec - how each hat is seated on the penguin's head, keyed by hat id.
      up    'z' if the model was made Z-up in Blender (most are), 'y' if already Y-up
      ow    overall width scale of the model
      dia   width of the hat's widest part once placed on the penguin
            (too small = hat perches on top instead of sliding down over the head)
      lift  nudge up (+) / down (-)
      c     [x, z] centre offset if the model is not centred
      Tip: start with  {up:'z', ow:1.0, dia:0.85}  and adjust by looking at it in-game.
   --------------------------------------------------------------------------- */
PP_CONTENT.pudgyHatSpec={
 crown3d:  {up:'z',ow:.81, dia:.90,lift:-.012},
 gentleman:{up:'z',ow:1.0, dia:1.0,lift:-.062},
 irish:    {up:'z',ow:1.0, dia:1.0,lift:.028},
 helmet:   {up:'z',ow:1.04,dia:.68},
 monk:     {up:'z',ow:1.0, dia:.66},
 pirate:   {up:'z',ow:.79, dia:.94,lift:-.010,c:[-.045,0]},
 pope:     {up:'z',ow:1.15,dia:.72},
 viking:   {up:'z',ow:1.0, dia:.96,lift:.006},
 winter:   {up:'z',ow:1.0, dia:.83,lift:-.003},
 wizard3d: {up:'z',ow:1.21,dia:.96,lift:.035},
 child:    {up:'z',ow:.99, dia:.82,lift:.019},
 witch:    {up:'y',ow:2.4, dia:.88,c:[-.09,.22]},
 cowboy:   {up:'z',ow:1.92,dia:.92,lift:-.01},
 pumpkin:  {up:'z',ow:1.35, dia:.92,lift:.01},
 hardhat:  {up:'z',ow:1.10,dia:.84,lift:0},
 /* New hats exported Y-up with the front along +Z (the old ones above are Z-up), so up:'y'. c = centre of the head-sized part of the model. */
 lowpolycap:{up:'y',ow:1.90,dia:.86,c:[0,.32]},
 sheriff:  {up:'y',ow:1.48,dia:.88,c:[0,.19]},
 knitwinter:{up:'y',ow:1.02,dia:.83,c:[0,-.15],yaw:180}
};

/* ---------------------------------------------------------------------------
   3) sunglasses - 3D glasses cut from assets/free_sunglasses_set_lowpoly.glb.
      Each row is  [id, 'Display Name', 'ObjectNameInsideTheGlb']
   --------------------------------------------------------------------------- */
PP_CONTENT.sunglasses=[
 ['vogue','Vogue Shades','Cube_Vogue_01_0'],['tommy','Tommy Shades','Plane_Tommy_01_0'],
 ['rayban','Rayban Shades','Plane.001_Rayban_01_0'],['osse','Osse Shades','Plane.002_Osse_01_0'],
 ['inesta3','Inesta Shield','Cube.001_Inesta_03_0'],['inesta2','Inesta Sport','Cube.002_Inesta_02_0'],
 ['inesta1','Inesta Classic','Plane.003_Inesta_01_0'],['mustang','Mustang Shades','Plane.004_Mustang_0']
];

/* Swimming goggles are glasses, not a hat. Loaded from assets/3d-hats/SwimmingGoggles.glb */
PP_CONTENT.goggles=[
 ['goggles','Swimming Goggles','SwimmingGoggles']
];
