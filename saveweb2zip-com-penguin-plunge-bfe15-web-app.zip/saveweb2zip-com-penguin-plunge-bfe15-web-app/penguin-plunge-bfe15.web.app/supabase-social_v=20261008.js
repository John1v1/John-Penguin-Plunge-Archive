/* =====================================================================================
   Penguin Plunge - Supabase friends + parties
   -------------------------------------------------------------------------------------
   Replaces the Firestore versions of: player search, friend requests, friends list,
   parties and party invites. It re-implements the same window.firebase* functions the
   game already calls, so the game code does not change.

   Needs the tables from supabase-setup.sql (run it once in the Supabase SQL editor).
   Load order in index.html:  supabase-js -> PP_SUPABASE_CONFIG -> supabase-multiplayer.js -> this file
   Sign-in, profiles, wallet, world chat and voice chat stay on Firebase.
   ===================================================================================== */
(function(){
'use strict';

const CFG = window.PP_SUPABASE_CONFIG || {};
if(!window.supabase || !CFG.url || !CFG.anonKey){
  console.warn('[pp-social] Supabase is not configured - keeping the Firebase friends/parties.');
  return;
}
const sb = (window.__ppNet && window.__ppNet.sb) || window.supabase.createClient(CFG.url, CFG.anonKey, { auth: { persistSession: false, autoRefreshToken: false } });

/* The old Firestore versions, kept only for a one-time look at old data (existing friends / players who have not updated yet). */
const OLD = { find: window.firebaseFindPlayer, findById: window.firebaseFindPlayerById, loadFriends: window.firebaseLoadFriends };

/* The game's own top-level variables (declared later with `let`, readable at call time). */
const me   = () => { try{ return (typeof uid !== 'undefined' && uid) || null; }catch(_){ return null; } };
const SV = () => { try{ return (typeof sv !== 'undefined' && sv) || {}; }catch(_){ return {}; } };
const PARTY_MAX = 12;
const DAY = 86400000;

const pairId = (a, b) => [a, b].sort().join('_');
const iso    = ms => new Date(ms).toISOString();
const ts     = v => { const ms = v ? Date.parse(v) : 0; return { toMillis: () => ms, seconds: Math.floor(ms / 1000) }; };
const withTimeout = (p, ms, msg) => Promise.race([Promise.resolve(p), new Promise((_, rej) => setTimeout(() => rej(new Error(msg || 'The game server did not answer. Try again in a minute.')), ms))]);

/* Every query goes through here: it gets a timeout, and turns Supabase's {error} into a thrown Error with a readable message. */
async function q(builder, label){
  const r = await withTimeout(builder, 12000, (label || 'Request') + ' timed out - the game server did not answer. Try again in a minute.');
  if(r && r.error){
    const m = String(r.error.message || r.error.code || 'error');
    if(/relation .* does not exist|schema cache|Could not find the table/i.test(m)){
      const e = new Error('Friends/parties are not set up yet - run supabase-setup.sql in your Supabase SQL editor.'); e.code = 'no-tables'; throw e;
    }
    const e = new Error(m); e.code = r.error.code; throw e;
  }
  return r.data;
}

/* =====================================================================================
   PLAYERS (search)
   ===================================================================================== */
const playerOut = r => ({ uid: r.uid, nm: r.nm, nmLower: r.nm_lower, xp: r.xp, rank: r.rank });

let lastCard = '';
window.firebaseEnsurePublicPlayer = async function(){
  const id = me() || (window.firebaseCurrentUser && window.firebaseCurrentUser.uid);
  if(!id) throw new Error('Sign in first.');
  const S = SV(), nm = String(S.nm || 'Penguin').slice(0, 12);
  const row = { uid: id, nm, nm_lower: nm.toLowerCase(), xp: Math.round(Number(S.xp || 0)), rank: (typeof rankInfo === 'function' ? rankInfo().name : 'Unranked'), updated_at: iso(Date.now()) };
  await q(sb.from('pp_players').upsert(row, { onConflict: 'uid' }), 'Saving your player card');
  lastCard = id + '|' + nm;
};
window.firebasePublishPlayer = async function(id, data){            // older call sites
  const nm = String((data && data.nm) || SV().nm || 'Penguin').slice(0, 12);
  await q(sb.from('pp_players').upsert({ uid: id, nm, nm_lower: nm.toLowerCase(), xp: Math.round(Number((data && data.xp) || SV().xp || 0)), rank: String((data && data.rank) || 'Player'), updated_at: iso(Date.now()) }, { onConflict: 'uid' }), 'Saving your player card');
};

/* Players who have not opened the new version yet only exist in the old Firestore list, so look there too (best effort, short timeout). */
const legacyFind = (name) => (typeof OLD.find === 'function')
  ? withTimeout(OLD.find(name), 4500, 'legacy').catch(() => []) : Promise.resolve([]);

window.firebaseFindPlayer = async function(nm){
  const name = String(nm || '').trim().slice(0, 12);
  if(!name) return [];
  const lower = name.toLowerCase();
  const legacy = legacyFind(name);
  let rows = await q(sb.from('pp_players').select('*').eq('nm_lower', lower).limit(8), 'Player search');
  if(!rows.length && lower.length >= 2){
    const end = lower.slice(0, -1) + String.fromCharCode(lower.charCodeAt(lower.length - 1) + 1);
    rows = await q(sb.from('pp_players').select('*').gte('nm_lower', lower).lt('nm_lower', end).limit(8), 'Player search');
  }
  let out = rows.map(playerOut);
  if(!out.length) out = await legacy;                                // only wait for the old list when there is nothing new
  const seen = new Set();
  return out.filter(x => x && x.uid && !seen.has(x.uid) && seen.add(x.uid));
};
window.firebaseFindPlayerById = async function(playerId){
  const id = String(playerId || '').trim();
  if(!id) return [];
  const rows = await q(sb.from('pp_players').select('*').eq('uid', id).limit(1), 'Player search');
  if(rows.length) return rows.map(playerOut);
  if(typeof OLD.findById === 'function'){ try{ return await withTimeout(OLD.findById(id), 4500, 'legacy'); }catch(_){} }
  return [];
};

/* =====================================================================================
   FRIENDS + FRIEND REQUESTS
   ===================================================================================== */
const reqOut = r => ({ id: r.id, from: r.from_uid, fromName: r.from_name, to: r.to_uid, toName: r.to_name, status: r.status, createdAt: ts(r.created_at), updatedAt: ts(r.updated_at) });

async function myRows(){
  const id = me(); if(!id) throw new Error('Sign in first.');
  const [a, b] = await Promise.all([
    q(sb.from('pp_friend_requests').select('*').eq('from_uid', id), 'Loading friends'),
    q(sb.from('pp_friend_requests').select('*').eq('to_uid', id), 'Loading friends')
  ]);
  const m = new Map(); a.concat(b).forEach(r => m.set(r.id, r));
  return Array.from(m.values()).map(reqOut);
}

/* One-time move of the old Firebase friend list into Supabase, so nobody loses their friends.
   Sources: the old Firestore list (if reachable) and the friends this browser already has saved. */
let migrated = null;
function migrateLegacyFriends(){
  const id = me(); if(!id) return Promise.resolve();
  const key = 'pp_sb_friends_migrated_' + id;
  try{ if(localStorage.getItem(key) === '1') return Promise.resolve(); }catch(_){}
  if(migrated && migrated.id === id) return migrated.p;
  const p = (async () => {
    const list = new Map();
    try{ (SV().friends || []).forEach(f => f && f.uid && list.set(f.uid, f.nm || 'Penguin')); }catch(_){}
    let legacyOk = false;
    if(typeof OLD.loadFriends === 'function'){
      try{ (await withTimeout(OLD.loadFriends(), 8000, 'legacy')).forEach(f => f && f.uid && list.set(f.uid, f.nm || 'Penguin')); legacyOk = true; }catch(_){}
    }
    const mine = String(SV().nm || 'Penguin').slice(0, 12);
    const rows = [];
    list.forEach((nm, other) => { if(other && other !== id) rows.push({ id: pairId(id, other), from_uid: id, from_name: mine, to_uid: other, to_name: nm, status: 'accepted', created_at: iso(Date.now()), updated_at: iso(Date.now()) }); });
    if(rows.length) await q(sb.from('pp_friend_requests').upsert(rows, { onConflict: 'id', ignoreDuplicates: true }), 'Moving your friends');   // never revives a removed friend
    if(legacyOk || !rows.length){ try{ localStorage.setItem(key, '1'); }catch(_){} }
  })().catch(e => { console.warn('[pp-social] friend migration will retry later:', e && e.message); migrated = null; });
  migrated = { id, p };
  return p;
}

window.firebaseSendFriendRequest = async function(toUid, toName){
  const id = me(); if(!id) throw new Error('Sign in first.');
  if(toUid === id) throw new Error('You cannot add yourself.');
  const rid = pairId(id, toUid);
  const ex = await q(sb.from('pp_friend_requests').select('*').eq('id', rid).limit(1), 'Sending request');
  const cur = ex[0];
  if(cur && cur.status === 'accepted') throw new Error('You are already friends.');
  if(cur && cur.status === 'pending' && cur.from_uid === id) throw new Error('A request is already pending.');
  if(cur && cur.status === 'pending' && cur.to_uid === id){          // they already asked you - just accept
    await window.firebaseAcceptFriendRequest(rid); return;
  }
  await q(sb.from('pp_friend_requests').upsert({ id: rid, from_uid: id, from_name: String(SV().nm || 'Penguin').slice(0, 12), to_uid: toUid, to_name: String(toName || 'Penguin').slice(0, 12), status: 'pending', created_at: iso(Date.now()), updated_at: iso(Date.now()) }, { onConflict: 'id' }), 'Sending request');
};
window.firebaseGetFriendRequests = async function(){
  const rows = await myRows(), id = me();
  return { incoming: rows.filter(x => x.to === id && x.status === 'pending'), outgoing: rows.filter(x => x.from === id && x.status === 'pending') };
};
async function loadReq(rid){
  const r = await q(sb.from('pp_friend_requests').select('*').eq('id', rid).limit(1), 'Friend request');
  return r[0] || null;
}
window.firebaseAcceptFriendRequest = async function(rid){
  const id = me(), r = await loadReq(rid);
  if(!r) throw new Error('Request no longer exists.');
  if(r.to_uid !== id) throw new Error('Not your request.');
  await q(sb.from('pp_friend_requests').update({ status: 'accepted', updated_at: iso(Date.now()) }).eq('id', rid), 'Accepting');
  const S = SV();
  if(Array.isArray(S.friends) && !S.friends.some(f => f.uid === r.from_uid)){ S.friends.push({ uid: r.from_uid, nm: r.from_name || 'Penguin' }); try{ if(typeof ppPersist === 'function') ppPersist(); }catch(_){} }
};
window.firebaseDeclineFriendRequest = async function(rid){
  const r = await loadReq(rid);
  if(!r || r.to_uid !== me()) throw new Error('Not your request.');
  await q(sb.from('pp_friend_requests').update({ status: 'declined', updated_at: iso(Date.now()) }).eq('id', rid), 'Declining');
};
window.firebaseCancelFriendRequest = async function(rid){
  const r = await loadReq(rid);
  if(!r || r.from_uid !== me()) throw new Error('Not your request.');
  await q(sb.from('pp_friend_requests').update({ status: 'cancelled', updated_at: iso(Date.now()) }).eq('id', rid), 'Cancelling');
};
window.firebaseRemoveFriend = async function(other){
  const id = me(); if(!id) return;
  const rid = pairId(id, other), r = await loadReq(rid);
  if(r && r.status === 'accepted') await q(sb.from('pp_friend_requests').update({ status: 'removed', updated_at: iso(Date.now()) }).eq('id', rid), 'Removing friend');
};
window.firebaseLoadFriends = async function(){
  const id = me(); if(!id) return [];
  await migrateLegacyFriends();
  const rows = await myRows();
  return rows.filter(x => x.status === 'accepted').map(x => x.from === id ? { uid: x.to, nm: x.toName || 'Penguin' } : { uid: x.from, nm: x.fromName || 'Penguin' });
};
/* The game calls this with a callback that receives every request row for the player (it also rebuilds the friends list from them). */
window.firebaseWatchFriendRequests = function(cb){
  if(!me()) return function(){};
  let stopped = false, timer = 0, sig = '';
  const tick = async () => {
    if(stopped) return;
    try{
      await migrateLegacyFriends();
      const rows = await myRows();
      const s = JSON.stringify(rows.map(r => [r.id, r.status]));
      if(s !== sig){ sig = s; if(!stopped) cb(rows); }
    }catch(e){ if(e && e.code === 'no-tables' && !tick.warned){ tick.warned = true; console.warn('[pp-social]', e.message); } }
    if(!stopped) timer = setTimeout(tick, (typeof document !== 'undefined' && document.hidden) ? 20000 : 6000);
  };
  tick();
  return function(){ stopped = true; clearTimeout(timer); };
};

/* =====================================================================================
   PARTIES
   party row   : pp_parties        (code = party id, host, sel, launch, status)
   member rows : pp_party_members  (code, uid, nm, pg, joined_at)
   ===================================================================================== */
/* The "pg" column holds the member's whole look: { pg: <pudgy colors>, se, ss, hh, os, eq, ac }.
   (Older rows hold just the pudgy colors.) Unwrap it so every client gets the real colors / equipped skin back. */
const memberOut = m => {
  const raw = m.pg, wrapped = !!raw && typeof raw === 'object' && ('se' in raw || 'eq' in raw || 'hh' in raw || 'os' in raw || 'ac' in raw || (raw.pg && typeof raw.pg === 'object'));
  const look = wrapped ? raw : { pg: raw || null };
  return { uid: m.uid, nm: m.nm, pg: look.pg || null, se: look.se || '', ss: look.ss || '', hh: look.hh || 0, os: look.os || '', eq: look.eq || 0, ac: look.ac || '', joinedAt: ts(m.joined_at) };
};
const partyOut = (p, members) => ({
  id: p.code, code: p.code, host: p.host, hostName: p.host_name, status: p.status,
  sel: p.sel || {}, launch: p.launch || null, createdAt: ts(p.created_at),
  members: (members || []).map(memberOut).sort((a, b) => a.joinedAt.toMillis() - b.joinedAt.toMillis()), membersLoaded: true
});
const myMember = () => {
  const S = SV(); let pg = null;
  try{ pg = (typeof cleanPudgy === 'function') ? cleanPudgy(S.pudgy || (typeof PUDGY_DEF !== 'undefined' ? PUDGY_DEF : null), true) : (S.pudgy || null); }catch(_){ pg = S.pudgy || null; }
  // Store the whole equipped look (same shape the game's partySyncLook writes) so a new member shows up with their real colors straight away.
  const look = { pg, se: S.shopEq || '', ss: S.shopEq ? ((S.skinStyles && S.skinStyles[S.shopEq]) || '') : '', hh: S.hat || 0, os: S.originalSkin || '', eq: S.eq || 0, ac: S.accessory || '' };
  return { uid: me(), nm: String(S.nm || 'Penguin').slice(0, 12), pg: look };
};

async function getParty(code){
  const rows = await q(sb.from('pp_parties').select('*').eq('code', String(code)).limit(1), 'Party');
  if(!rows.length) return null;
  const members = await q(sb.from('pp_party_members').select('*').eq('code', String(code)), 'Party');
  return partyOut(rows[0], members);
}
async function addMember(code){
  const m = myMember();
  await q(sb.from('pp_party_members').upsert({ code, uid: m.uid, nm: m.nm, pg: m.pg, joined_at: iso(Date.now()) }, { onConflict: 'code,uid', ignoreDuplicates: true }), 'Joining party');
}

window.firebaseGetMyParty = async function(){
  const id = me(); if(!id) return null;
  const mine = await q(sb.from('pp_party_members').select('code').eq('uid', id), 'Party');
  const codes = mine.map(r => r.code);
  if(!codes.length) return null;
  const parties = await q(sb.from('pp_parties').select('*').in('code', codes).eq('status', 'open').gte('updated_at', iso(Date.now() - 12 * 3600000)), 'Party');
  if(!parties.length) return null;
  const p = parties.sort((a, b) => Date.parse(b.updated_at) - Date.parse(a.updated_at))[0];
  const members = await q(sb.from('pp_party_members').select('*').eq('code', p.code), 'Party');
  return partyOut(p, members);
};
window.firebaseClearPartyPointer = async function(){};              // nothing to clear: membership rows are the pointer

window.firebaseCreateParty = async function(sel){
  const id = me(); if(!id) throw new Error('Sign in first.');
  const old = await window.firebaseGetMyParty().catch(() => null);
  if(old) await window.firebaseLeaveParty();
  const s0 = sel || {};
  const selOut = { cat: s0.cat == null ? 2 : s0.cat | 0, md: s0.md == null ? 6 : s0.md | 0, rm: s0.rm == null ? -1 : s0.rm | 0 };
  let code = '', made = false;
  for(let i = 0; i < 8 && !made; i++){
    code = String(Math.floor(10000 + Math.random() * 90000));
    const ex = await q(sb.from('pp_parties').select('code,status').eq('code', code).limit(1), 'Party');
    if(ex.length && ex[0].status === 'open') continue;               // that code is in use by a live party
    if(ex.length) await q(sb.from('pp_parties').delete().eq('code', code), 'Party');   // old closed party with the same code
    await q(sb.from('pp_parties').insert({ code, host: id, host_name: String(SV().nm || 'Penguin').slice(0, 12), status: 'open', sel: selOut, launch: null }), 'Creating party');
    made = true;
  }
  if(!made) throw new Error('Could not find a free party code. Try again.');
  await addMember(code);
  return { id: code, code };
};
window.firebaseJoinParty = async function(code){
  const id = me(); if(!id) throw new Error('Sign in first.');
  const c = String(code).trim();
  const p = await getParty(c);
  if(!p || p.status !== 'open') throw new Error('Party code not found or the party is closed.');
  const cur = await window.firebaseGetMyParty().catch(() => null);
  if(cur && cur.id === p.id) return { id: p.id, code: p.code };
  if(p.members.length >= PARTY_MAX && !p.members.some(m => m.uid === id)) throw new Error('That party is full (' + PARTY_MAX + ' players).');
  if(cur) await window.firebaseLeaveParty();
  await addMember(p.code);
  return { id: p.id, code: p.code };
};
window.firebaseLeaveParty = async function(){
  const id = me(); if(!id) return;
  /* Remove EVERY party-member row of mine and close any open party I host. This no longer depends on finding "my current party"
     first (that lookup skipped parties older than 12 hours, so leaving silently did nothing and the player stayed on everyone's screen). */
  let mine = [];
  try{ mine = await q(sb.from('pp_party_members').select('code').eq('uid', id), 'Leaving party'); }catch(_){}
  try{ await q(sb.from('pp_parties').update({ status: 'closed', updated_at: iso(Date.now()) }).eq('host', id).eq('status', 'open'), 'Leaving party'); }catch(_){}
  try{ await q(sb.from('pp_party_members').delete().eq('uid', id), 'Leaving party'); }catch(e){
    for(const r of mine){ try{ await q(sb.from('pp_party_members').delete().eq('code', r.code).eq('uid', id), 'Leaving party'); }catch(_){} }
  }
};
window.firebaseLeavePartyAsMember = async function(partyId){
  const id = me(); if(!id || !partyId) return;
  try{ await q(sb.from('pp_party_members').delete().eq('code', String(partyId)).eq('uid', id), 'Leaving party'); }catch(_){}
};
window.firebaseKickPartyMember = async function(partyId, memberUid){
  const id = me(); if(!id || !partyId || !memberUid || memberUid === id) return;
  await q(sb.from('pp_party_members').delete().eq('code', String(partyId)).eq('uid', memberUid), 'Removing player');
};
window.firebaseSetPartySel = async function(partyId, sel){
  await q(sb.from('pp_parties').update({ sel: { cat: sel.cat | 0, md: sel.md | 0, rm: sel.rm == null ? -1 : sel.rm | 0 }, updated_at: iso(Date.now()) }).eq('code', String(partyId)).eq('host', me()), 'Updating party');
};
/* Instant "the host pressed Play" signal: members already poll the party, but only every 2 s, so their loading screens used to start at different times.
   The host broadcasts on a small channel per party and every member's watcher refreshes the party at once. */
const launchChs = new Map();
window.firebaseLaunchParty = async function(partyId, launch){
  await q(sb.from('pp_parties').update({ launch, updated_at: iso(Date.now()) }).eq('code', String(partyId)).eq('host', me()), 'Starting game');
  try{
    const ch = launchChs.get(String(partyId));
    if(ch) await ch.send({ type: 'broadcast', event: 'launch', payload: { id: launch && launch.id } });
  }catch(_){}
};
window.firebaseUpdatePartyLook = async function(partyId, pg, nm){
  const id = me(); if(!id) return;
  await q(sb.from('pp_party_members').update({ pg, nm: nm || SV().nm }).eq('code', String(partyId)).eq('uid', id), 'Updating look');
};

/* The game gives us a callback and expects the whole party (members included) every time something changes.
   Polls every 2 s (every 8 s while the tab is hidden) and only calls back when something changed. */
window.firebaseWatchParty = function(partyId, cb){
  const code = String(partyId);
  let stopped = false, timer = 0, sig = null, fails = 0, busy = false, again = false, lch = null;
  const tick = async () => {
    if(stopped) return;
    if(busy){ again = true; return; }                               // a refresh is already running: run one more right after it
    busy = true;
    try{
      const p = await getParty(code);
      fails = 0;
      if(stopped) return;
      const id = me();
      const s = p ? JSON.stringify([p.status, p.host, p.sel, p.launch, p.members.map(m => [m.uid, m.nm, m.pg, m.se, m.ss, m.hh, m.os, m.eq, m.ac])]) : 'gone';
      const missingMe = !!(p && id && !p.members.some(m => m.uid === id));
      if(s !== sig || missingMe){ sig = s; cb(p); }                  // while we are missing from the member list keep reporting, so the game can drop the party
      if(!p) return;                                                  // party deleted: the game ends it, stop polling
    }catch(e){ fails++; if(fails === 3) console.warn('[pp-social] party watch is having trouble:', e && e.message); }
    busy = false;
    if(stopped) return;
    clearTimeout(timer);
    timer = setTimeout(tick, again ? 0 : ((typeof document !== 'undefined' && document.hidden) ? 8000 : 2000));
    again = false;
  };
  try{
    lch = sb.channel('pp:party-launch:' + code, { config: { broadcast: { self: false, ack: false } } });
    lch.on('broadcast', { event: 'launch' }, () => { if(!stopped){ again = true; if(!busy){ clearTimeout(timer); tick(); } } });
    lch.subscribe();
    launchChs.set(code, lch);
  }catch(_){ lch = null; }
  tick();
  return () => { stopped = true; clearTimeout(timer); if(lch){ if(launchChs.get(code) === lch) launchChs.delete(code); try{ sb.removeChannel(lch); }catch(_){} } };
};

/* ---- party invites ---- */
const invOut = r => ({ id: r.id, partyId: r.code, code: r.code, from: r.from_uid, fromName: r.from_name, to: r.to_uid, status: r.status, createdAt: ts(r.created_at) });
window.firebaseInviteToParty = async function(toUid, partyId, code){
  const id = me(); if(!id) throw new Error('Sign in first.');
  await q(sb.from('pp_party_invites').insert({ code: String(partyId || code), from_uid: id, from_name: String(SV().nm || 'Penguin').slice(0, 12), to_uid: toUid, status: 'pending' }), 'Sending invite');
};
window.firebaseGetPartyInvites = async function(){
  const id = me(); if(!id) throw new Error('Sign in first.');
  const rows = await q(sb.from('pp_party_invites').select('*').eq('to_uid', id).eq('status', 'pending').gte('created_at', iso(Date.now() - DAY)), 'Loading invites');
  return rows.map(invOut);
};
window.firebaseAcceptPartyInvite = async function(inv){
  const id = me(); if(!id) throw new Error('Sign in first.');
  if(!inv || inv.to !== id) throw new Error('Invite is not for you.');
  const p = await getParty(inv.partyId);
  if(!p || p.status !== 'open') throw new Error('That party is no longer open.');
  const cur = await window.firebaseGetMyParty().catch(() => null);
  if(!cur || cur.id !== inv.partyId){
    if(p.members.length >= PARTY_MAX && !p.members.some(m => m.uid === id)) throw new Error('That party is full (' + PARTY_MAX + ' players).');
    if(cur) await window.firebaseLeaveParty();
  }
  await addMember(p.code);
  await q(sb.from('pp_party_invites').update({ status: 'accepted', updated_at: iso(Date.now()) }).eq('id', inv.id), 'Accepting invite');
  return { id: p.id, code: p.code };
};
window.firebaseDeclinePartyInvite = async function(invId){
  const id = me(); if(!id) throw new Error('Sign in first.');
  await q(sb.from('pp_party_invites').update({ status: 'declined', updated_at: iso(Date.now()) }).eq('id', invId).eq('to_uid', id), 'Declining invite');
};

window.__ppSocial = { sb, migrateLegacyFriends };
console.info('[pp-social] Supabase friends + parties active');
})();
