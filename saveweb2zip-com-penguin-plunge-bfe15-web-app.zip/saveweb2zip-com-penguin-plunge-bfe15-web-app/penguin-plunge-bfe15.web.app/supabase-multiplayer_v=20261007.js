/* =====================================================================================
   Penguin Plunge - Supabase Realtime multiplayer adapter
   -------------------------------------------------------------------------------------
   Replaces the Firestore-backed ROOM and ONLINE-LIST code with Supabase Realtime
   (Broadcast + Presence). It re-implements the same window.firebase* functions the game
   already calls, so the game code itself does not change:

     firebaseOpenGameRoom(room, initial) -> {roomId, peers(), presence(data), onPeers(cb,onDis), leave()}
     firebasePeekRoom(room)              -> [{peer, sameTab, presence}]
     firebaseSetCTFState / firebaseWatchCTFState
     firebaseSetServerPresence / firebaseWatchServerPresence / firebaseGetServerPlayer

   Still on Firebase (unchanged): sign-in, profiles, wallet, friends, parties, world chat,
   voice-chat signalling.

   Load order in index.html:  supabase-js  ->  (Firebase block)  ->  PP_SUPABASE_CONFIG  ->  this file
   ===================================================================================== */
(function(){
'use strict';

const CFG = window.PP_SUPABASE_CONFIG || {};
if(!window.supabase || !CFG.url || !CFG.anonKey){
  console.warn('[pp-net] Supabase is not configured - keeping the Firebase rooms.');
  return;
}

/* ---- tunables ------------------------------------------------------------------- */
const NET = {
  fullEveryMs: 5000,       // every client re-sends its whole state this often (heals any lost delta)
  lobbyMinTrackMs: 6500,   // Presence updates per client are rate-limited by Supabase (5 per 30 s) - stay under it
  lobbyRefreshMs: 30000,   // re-emit the online list so rows never look stale to the game's freshness check
  leaveGraceMs: 45000,     // a player whose connection drops stays in the room this long, so a reconnect is never mistaken for leaving / being kicked
  chillCap: 40,            // max humans in a Halloween Chill Space room
  eventsPerSecond: 30      // client-side send throttle
};

const sb = window.supabase.createClient(CFG.url, CFG.anonKey, {
  auth: { persistSession: false, autoRefreshToken: false },   // no Supabase accounts yet, identity stays on Firebase
  realtime: { params: { eventsPerSecond: NET.eventsPerSecond } }
});

/* ---- small helpers -------------------------------------------------------------- */
let fallbackId = null;
function myId(){
  try{ const u = window.firebaseCurrentUser || (window.firebaseAuth && window.firebaseAuth.currentUser); if(u && u.uid) return u.uid; }catch(_){}
  if(window.firebasePresenceUid) return window.firebasePresenceUid;
  if(!fallbackId){
    try{ fallbackId = sessionStorage.getItem('pp_net_id'); }catch(_){}
    if(!fallbackId){
      fallbackId = 'g' + Math.random().toString(36).slice(2, 12);
      try{ sessionStorage.setItem('pp_net_id', fallbackId); }catch(_){}
    }
  }
  return fallbackId;
}
function save(){ try{ return (typeof sv !== 'undefined' && sv) || {}; }catch(_){ return {}; } }   // the game's `sv` save object
const same = (a, b) => a === b || (typeof a === 'object' && typeof b === 'object' && JSON.stringify(a) === JSON.stringify(b));
const waitFor = (fn, ms) => new Promise(r => { const t0 = Date.now(); (function p(){ if(fn() || Date.now() - t0 > ms) return r(); setTimeout(p, 40); })(); });

/* One operation at a time per room name, so a leave() always finishes before the next join/peek of that room. */
const locks = new Map();
function withLock(key, fn){
  const prev = locks.get(key) || Promise.resolve();
  const next = prev.catch(() => {}).then(fn);
  locks.set(key, next);
  next.then(() => {}, () => {}).then(() => { if(locks.get(key) === next) locks.delete(key); });
  return next;
}

/* supabase-js returns the SAME channel object for a topic that is still registered, and you cannot add listeners to a
   channel that is already subscribed - so always drop any leftover channel first. */
async function freshChannel(topic, config){
  const old = sb.getChannels().find(c => c.topic === 'realtime:' + topic);
  if(old){ try{ await sb.removeChannel(old); }catch(_){} }
  return sb.channel(topic, { config });
}

/* Resolves on the first SUBSCRIBED; later status changes (reconnects) go to onLater. */
function subscribe(ch, onLater, timeoutMs){
  return new Promise((resolve, reject) => {
    let done = false;
    const t = setTimeout(() => { if(!done){ done = true; reject(new Error('Realtime subscribe timed out')); } }, timeoutMs || 10000);
    ch.subscribe(st => {
      if(!done){
        if(st === 'SUBSCRIBED'){ done = true; clearTimeout(t); resolve(); }
        else if(st === 'CHANNEL_ERROR' || st === 'TIMED_OUT' || st === 'CLOSED'){ done = true; clearTimeout(t); reject(new Error('Realtime channel ' + st)); }
        return;
      }
      if(onLater) onLater(st);
    });
  });
}

/* =====================================================================================
   1) ONLINE LIST  (one global Presence channel; replaces the "serverPlayers" collection)
      - Presence removes a player automatically when their connection drops, so there are
        no heartbeats, no stale-row cut-offs and no read quota to burn.
   ===================================================================================== */
const LOBBY_KEYS = ['nm', 'rg', 'cat', 'md', 'roomId', 'ph', 'm', 'g'];
const lobby = { ch: null, id: null, ready: null, joined: false, tracked: false, state: {}, lastTrack: 0, trackT: 0, emitT: 0, cbs: new Set() };

function lobbyRows(){
  if(!lobby.ch) return [];
  const st = lobby.ch.presenceState(), now = Date.now(), rows = [];
  for(const key of Object.keys(st)){
    const metas = st[key] || [], meta = metas[metas.length - 1] || {};
    const row = Object.assign({}, meta, { uid: key, ownerUid: meta.ownerUid || key, online: meta.online !== false, updatedAt: now });
    delete row.presence_ref;
    rows.push(row);
  }
  return rows;
}
function lobbyEmit(){
  window.__ppPresSnapAt = Date.now();
  window.__ppPresReadErr = null;
  const rows = lobbyRows();
  lobby.cbs.forEach(cb => { try{ cb(rows); }catch(e){ console.warn('[pp-net] online-list callback failed', e); } });
}
function lobbyEmitSoon(){ if(lobby.emitT) return; lobby.emitT = setTimeout(() => { lobby.emitT = 0; lobbyEmit(); }, 250); }

function lobbyTrack(force){
  clearTimeout(lobby.trackT);
  if(!lobby.joined) return;                                   // the SUBSCRIBED handler tracks as soon as we are connected
  const wait = force ? 0 : Math.max(0, lobby.lastTrack + NET.lobbyMinTrackMs - Date.now());
  lobby.trackT = setTimeout(async () => {
    lobby.lastTrack = Date.now();
    try{
      await lobby.ch.track(Object.assign({}, lobby.state, { online: true }));
      lobby.tracked = true;
      window.__ppPresOK = Date.now();
      window.__ppPresWriteErr = null;
    }catch(e){ window.__ppPresWriteErr = String((e && e.message) || e); }
  }, wait);
}

function lobbyEnsure(){
  const id = myId();
  if(lobby.ch && lobby.id === id) return lobby.ready;
  if(lobby.ch){ const old = lobby.ch; lobby.ch = null; sb.removeChannel(old).catch(() => {}); }   // signed in/out -> new presence key
  lobby.id = id; lobby.joined = false; lobby.tracked = false;
  const ch = sb.channel('pp:online', { config: { presence: { key: id } } });
  lobby.ch = ch;
  ch.on('presence', { event: 'sync' }, lobbyEmitSoon);
  lobby.ready = subscribe(ch, st => {
    if(st === 'SUBSCRIBED'){ lobby.joined = true; lobby.tracked = false; lobbyTrack(true); }   // re-announce after an automatic reconnect
    else { lobby.joined = false; }
  }).then(() => {
    lobby.joined = true;
    window.__ppPresOK = Date.now();
    window.__ppPresWriteErr = null;
    if(Object.keys(lobby.state).length) lobbyTrack(true);
    lobbyEmit();
  }).catch(e => {
    window.__ppPresReadErr = window.__ppPresWriteErr = String((e && e.message) || e);
    if(lobby.ch === ch){ lobby.ch = null; }
    sb.removeChannel(ch).catch(() => {});
    throw e;
  });
  lobby.ready.catch(() => {});
  return lobby.ready;
}
setInterval(() => { if(lobby.cbs.size) lobbyEmit(); if(lobby.joined && lobby.tracked) window.__ppPresOK = Date.now(); }, NET.lobbyRefreshMs);

window.firebaseSetServerPresence = async function(_uid, data){
  data = data || {};
  await lobbyEnsure();
  if(data.online === false){                                  // tab closed / signed out
    clearTimeout(lobby.trackT);
    try{ await lobby.ch.untrack(); }catch(_){}
    lobby.tracked = false;
    return;
  }
  const next = Object.assign({}, lobby.state);
  for(const k of LOBBY_KEYS) if(data[k] !== undefined) next[k] = data[k];
  const changed = !lobby.tracked || JSON.stringify(next) !== JSON.stringify(lobby.state);
  lobby.state = next;
  if(changed) lobbyTrack(false);
  else window.__ppPresOK = Date.now();                        // unchanged heartbeat: nothing to send, connection is fine
};
window.firebaseWatchServerPresence = function(cb){
  lobby.cbs.add(cb);
  lobbyEnsure().then(lobbyEmit, () => {});
  setTimeout(() => cb(lobbyRows()), 0);
  return () => { lobby.cbs.delete(cb); };
};
window.firebaseGetServerPlayer = async function(id){
  await lobbyEnsure().catch(() => {});
  return lobbyRows().find(r => r.uid === id || r.ownerUid === id) || null;
};

/* =====================================================================================
   2) GAME ROOMS  (one channel per room)
      - Presence  = who is in the room (auto-removed on disconnect)
      - Broadcast = everything that changes: position at ~5/s, look, phase, tile mask (bm/bs/bk)
        sent as DELTAS, plus a full state every few seconds and whenever someone new joins.
        That "full state on join" is what shows a late joiner the tiles/platforms that are
        already broken.
   ===================================================================================== */
const openRooms = new Map();    // roomName -> { list(), setCtf(), watchCtf() }

window.firebaseOpenGameRoom = function(roomName, initial){
  return withLock('room:' + roomName, async () => {
    const id = myId(), S0 = save();
    const isChill = /^halloween-chill/i.test(String(roomName || '')) || S0.md === 10;
    const ch = await freshChannel('pp:room:' + roomName, { broadcast: { self: false, ack: false }, presence: { key: id } });

    const peers = new Map();            // peerId -> merged state
    const members = new Set();          // peerIds currently present (or dropped less than leaveGraceMs ago)
    const graceAt = new Map();          // peerId -> when their connection dropped (still counted as present until the grace runs out)
    const byed = new Set();             // peers that told us they left on purpose (no grace)
    let graceT = 0;
    const peerCbs = new Set(), disCbs = new Set(), ctfCbs = new Set();
    let state = Object.assign({ uid: id, nm: S0.nm, rg: S0.rg, cat: S0.cat, ph: 'lobby', a: 1, roomId: roomName, isHuman: true, isBot: false }, initial || {}, { uid: id, isHuman: true, isBot: false });
    let left = false, joined = false, firstSync = false, emitT = 0, fullT = 0, badT = 0;
    let ctf = null, ctfVer = 0, ctfFrom = '';

    const touch = (pid, d, replace) => {
      const base = replace ? {} : (peers.get(pid) || {});
      peers.set(pid, Object.assign(base, d, { uid: pid, updatedAt: Date.now() }));
      const pr = peers.get(pid);
      if(pr.isHuman === undefined) pr.isHuman = true;           // everyone on a room channel is a real player
      if(pr.isBot === undefined) pr.isBot = false;
    };
    const list = () => {
      touch(id, {});                                            // keep my own row fresh
      const out = [];
      peers.forEach((p, pid) => { if(pid === id || members.has(pid)) out.push({ peer: pid, sameTab: pid === id, presence: p }); });
      return out;
    };
    const emit = () => {
      if(emitT) return;
      emitT = setTimeout(() => { emitT = 0; if(left) return; const l = list(); peerCbs.forEach(cb => { try{ cb({ peers: l }); }catch(e){ console.warn('[pp-net] onPeers callback failed', e); } }); }, 30);
    };
    const send = (event, payload) => {
      if(!joined || left) return Promise.resolve();
      return ch.send({ type: 'broadcast', event, payload }).catch(() => {});
    };
    const sendFull = (to, jitter) => setTimeout(() => {
      if(left || !joined) return;
      send('full', { id, to: to || null, d: state });
      if(ctf && to) send('ctf', { id: ctfFrom, v: ctfVer, d: ctf });
    }, jitter ? Math.random() * 250 : 0);

    /* ---- incoming ---- */
    ch.on('broadcast', { event: 'st' }, ({ payload }) => {
      if(!payload || !payload.id || payload.id === id) return;
      touch(payload.id, payload.d || {}); emit();
    });
    ch.on('broadcast', { event: 'full' }, ({ payload }) => {
      if(!payload || !payload.id || payload.id === id) return;
      if(payload.to && payload.to !== id) return;
      touch(payload.id, payload.d || {}, true); emit();
    });
    const applyCtf = p => {
      if(!p || (p.v < ctfVer) || (p.v === ctfVer && String(p.id || '') < ctfFrom)) return;
      ctfVer = p.v; ctfFrom = String(p.id || ''); ctf = p.d;
      ctfCbs.forEach(cb => { try{ cb(ctf); }catch(_){} });
    };
    ch.on('broadcast', { event: 'ctf' }, ({ payload }) => { if(payload && payload.id !== id) applyCtf(payload); });
    /* Rebuild who is here from the live presence list, but keep anyone whose connection just dropped for a short grace period. */
    const rebuildMembers = () => {
      const now = Date.now(), live = new Set(Object.keys(ch.presenceState()));
      live.forEach(k => { graceAt.delete(k); byed.delete(k); });
      members.forEach(k => { if(k !== id && !live.has(k) && !byed.has(k) && !graceAt.has(k)) graceAt.set(k, now); });
      graceAt.forEach((t, k) => { if(now - t > NET.leaveGraceMs || byed.has(k)){ graceAt.delete(k); peers.delete(k); } });
      members.clear();
      live.forEach(k => members.add(k));
      graceAt.forEach((t, k) => members.add(k));
      members.add(id);
      clearTimeout(graceT);
      if(graceAt.size) graceT = setTimeout(() => { if(left) return; rebuildMembers(); emit(); }, 1000);
    };
    ch.on('broadcast', { event: 'bye' }, ({ payload }) => {
      if(!payload || !payload.id || payload.id === id) return;
      byed.add(payload.id); graceAt.delete(payload.id); members.delete(payload.id); peers.delete(payload.id); emit();
    });
    ch.on('presence', { event: 'sync' }, () => {
      firstSync = true;
      rebuildMembers();
      const now = Date.now();
      peers.forEach((p, pid) => { if(pid !== id && !members.has(pid) && now - (p.updatedAt || 0) > 15000) peers.delete(pid); });
      emit();
    });
    ch.on('presence', { event: 'join' }, ({ key }) => { if(key && key !== id){ graceAt.delete(key); byed.delete(key); members.add(key); sendFull(key, true); } emit(); });
    ch.on('presence', { event: 'leave' }, ({ key }) => {
      if(!key || key === id) return;
      if(byed.has(key)){ members.delete(key); peers.delete(key); }
      else if(!graceAt.has(key)){ graceAt.set(key, Date.now()); clearTimeout(graceT); graceT = setTimeout(() => { if(left) return; rebuildMembers(); emit(); }, 1000); }   // dropped: keep them for a while
      emit();
    });

    /* ---- connect ---- */
    try{
      await subscribe(ch, st => {
        if(st === 'SUBSCRIBED'){                                 // automatic reconnect
          clearTimeout(badT); joined = true;
          ch.track({ uid: id, nm: state.nm, isHuman: true, isBot: false }).catch(() => {});
          sendFull(null, false);
        }else if(st === 'CHANNEL_ERROR' || st === 'TIMED_OUT' || st === 'CLOSED'){
          joined = false; clearTimeout(badT);
          badT = setTimeout(() => { if(!joined && !left) disCbs.forEach(cb => { try{ cb(); }catch(_){} }); }, 10000);
        }
      });
      joined = true;

      if(isChill){                                               // Chill Space cap: count humans already present
        await waitFor(() => firstSync, 1500);
        const others = Object.keys(ch.presenceState()).filter(k => k !== id).length;
        if(others >= NET.chillCap) throw new Error('CHILL_FULL');
      }
      await ch.track({ uid: id, nm: state.nm, isHuman: true, isBot: false });
    }catch(e){
      left = true;
      try{ await sb.removeChannel(ch); }catch(_){}
      throw e;
    }

    touch(id, state);
    members.add(id);
    sendFull(null, false);                                       // introduce myself
    fullT = setInterval(() => { if(!left) send('full', { id, to: null, d: state }); }, NET.fullEveryMs);

    const api = {
      roomId: roomName,
      peers: () => list(),
      presence: async data => {
        if(left) return;
        const d = Object.assign({}, data || {}, { uid: id, nm: save().nm, rg: save().rg, cat: save().cat, roomId: roomName, isHuman: true, isBot: false });
        const delta = {};
        for(const k of Object.keys(d)) if(!same(state[k], d[k])) delta[k] = d[k];
        state = Object.assign({}, state, d);
        touch(id, state);
        if(Object.keys(delta).length) await send('st', { id, d: delta });   // standing still sends nothing
        const lob = {}; for(const k of ['ph', 'm', 'g']) if(d[k] !== undefined) lob[k] = d[k];
        if(Object.keys(lob).length) window.firebaseSetServerPresence(id, Object.assign({ roomId: roomName, nm: state.nm, rg: state.rg, cat: state.cat }, lob)).catch(() => {});
        emit();
      },
      onPeers: (cb, onDisconnect) => {
        peerCbs.add(cb); if(onDisconnect) disCbs.add(onDisconnect);
        setTimeout(() => { if(!left && peerCbs.has(cb)) cb({ peers: list() }); }, 0);   // like a Firestore snapshot: fire once straight away
        return () => { peerCbs.delete(cb); if(onDisconnect) disCbs.delete(onDisconnect); };
      },
      leave: async () => {
        if(left) return;
        try{ await Promise.race([ch.send({ type: 'broadcast', event: 'bye', payload: { id } }), new Promise(r => setTimeout(r, 400))]); }catch(_){}   // tell everyone right away (no grace) that this leave is on purpose
        left = true; clearInterval(fullT); clearTimeout(badT); clearTimeout(emitT); clearTimeout(graceT); peerCbs.clear(); disCbs.clear(); ctfCbs.clear();
        if(openRooms.get(roomName) === room) openRooms.delete(roomName);
        try{ await ch.untrack(); }catch(_){}
        try{ await sb.removeChannel(ch); }catch(_){}
        try{ await window.firebaseSetServerPresence(id, { online: true, roomId: null, ph: 'menu', nm: save().nm, rg: save().rg, cat: save().cat }); }catch(_){}
      }
    };

    const room = {
      list: () => list(),
      setCtf: data => { ctfVer += 1; ctfFrom = id; ctf = data; ctfCbs.forEach(cb => { try{ cb(ctf); }catch(_){} }); send('ctf', { id, v: ctfVer, d: data }); },
      watchCtf: cb => { ctfCbs.add(cb); setTimeout(() => { if(ctfCbs.has(cb)) cb(ctf); }, 0); return () => ctfCbs.delete(cb); }
    };
    openRooms.set(roomName, room);

    // show this room in the online list straight away (friends can then see and join it)
    window.firebaseSetServerPresence(id, { roomId: roomName, ph: state.ph, nm: state.nm, rg: state.rg, cat: state.cat }).catch(() => {});
    return api;
  });
};

/* Look at who is in a room WITHOUT joining it (matchmaking). */
window.firebasePeekRoom = function(roomName){
  const active = openRooms.get(roomName);
  if(active) return Promise.resolve(active.list());
  return withLock('room:' + roomName, async () => {
    const ch = await freshChannel('pp:room:' + roomName, {});
    let synced = false;
    ch.on('presence', { event: 'sync' }, () => { synced = true; });
    try{
      await subscribe(ch, null, 5000);
      await waitFor(() => synced, 1200);
      const st = ch.presenceState(), now = Date.now(), me = myId();
      return Object.keys(st).map(k => {
        const metas = st[k] || [], meta = metas[metas.length - 1] || {};
        return { peer: k, sameTab: k === me, presence: Object.assign({}, meta, { uid: k, isHuman: true, isBot: false, updatedAt: now }) };
      });
    }finally{
      try{ await sb.removeChannel(ch); }catch(_){}
    }
  });
};

/* Capture-the-flag shared state: lives inside the room channel (see setCtf / watchCtf above). */
window.firebaseSetCTFState = async function(roomName, data){
  const r = openRooms.get(roomName); if(r) r.setCtf(data);
};
window.firebaseWatchCTFState = function(roomName, cb){
  let off = null, stopped = false, tries = 0;
  const attach = () => {
    if(stopped) return;
    const r = openRooms.get(roomName);
    if(r){ off = r.watchCtf(cb); return; }
    if(++tries < 25) setTimeout(attach, 200);                    // the room is still connecting
    else cb(null);
  };
  attach();
  return () => { stopped = true; if(off) off(); };
};

window.__ppNet = { sb, lobby, openRooms, NET };                  // for debugging in the console
console.info('[pp-net] Supabase Realtime multiplayer active');
})();
